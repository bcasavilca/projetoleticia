﻿select * from produto
